import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // integer which will hold my board number size
        int n = 3;
        //creating the array. using my "int"means game can get bigger
        char[][] game = new char[n][n];

        //starting a clean board
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                game[i][j] = '_';
            }
        }
        // scanner to take the names of the players
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter your name player 1");
        String p1 = scanner.nextLine();
        System.out.println("player 2 enter your name ");
        String p2 = scanner.nextLine();
        //a boolean to know whose turn it is
        boolean player1 = true;
        //creating a boolean for the end of the game(all fields are full or someone really won
        boolean gameOver = false;
        while (!gameOver) {
            //draw the board
            drawBoard(game);

            //players are playing in turns
            if (player1) {
                System.out.println(p1 + "'s turn (x):");
            } else {
                System.out.println(p2 + "'s turn (o):");
            }
            //creating a char to hold the empty space and the assing x or o
            char c = '_';
            if (player1) {
                c = 'x';
            } else {
                c = 'o';
            }
            //creating the rows and columns
            int row = 0;
            int col = 0;

            //creating a while loop to check if player is filling in valid  array rule
            while (true) {
                //asking players for rows and columns
                System.out.println("in which col and row should I place  your move");
                row = scanner.nextInt();
                col = scanner.nextInt();
                // check for valid placing on the board
                if (row < 0 || col < 0 || row >= n || col >= n) {
                    System.out.println("the placing is not correct please try again");
                    //check if the position is empty
                } else if (game[row][col] != '_') {
                    System.out.println("this place is already taken ");
                } else {
                    break;
                }
            }
            //setting the start of the game and each turn to "c"
            game[row][col] = c;
            // checking for victor
            if (playerWon(game) == 'x') {
                System.out.println(p1 + "has won");
                gameOver = true;
            } else if (playerWon(game) == 'o') {
                System.out.println(p2 + "has won");
                gameOver = true;
            } else {
                //check for a full board
                if (fullBoard(game)) {
                    System.out.println("game is tied");
                    gameOver = true;
                } else {
                    //this will make the players switch
                    player1 = !player1;

                }
            }
        }
        drawBoard(game);
    }

    //making a function to draw the board
    public static void drawBoard(char[][] board) {
        System.out.println("board:");
        for (int i = 0; i < board.length; i++) {
            //making the inner loop
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println();

        }
    }
    //making a function for checking who's the winner
    public static char playerWon(char[][] game) {
        //checking rows
        for (int i = 0; i < game.length; i++) {
            boolean inArow = true;
            char value = game[i][0];

            if (value == '_') {
                inArow = false;
            } else {
                for (int j = 1; j < game[i].length; j++) {
                    if (game[i][j] != value) {
                        inArow = false;
                        break;
                    }
                }
            }
            if (inArow) {
                return value;
            }
        }
        for (int j = 0; j < game[0].length; j++) {
            boolean inAcol = true;
            char value = game[0][j];
            if (value == '_') {
                inAcol = false;
            } else {
                for (int i = 1; j < game.length; j++) {
                    if (game[i][j] != value) {
                        inAcol = false;
                        break;
                    }
                }
            }
            if (inAcol) {
                return value;
            }
        }
        //checking diagonals from top left
        boolean inDiagonal1 = true;
        char value1 = game[0][0];
        if (value1 == '_') {
            inDiagonal1 = false;
        } else {

            for ( int i = 1; i < game.length; i++) {
            if (game[i][i] != value1) {
                inDiagonal1 = false;
                break;
            }

            }
        }
        if (inDiagonal1) {
            return value1;
        }
        //checking diagonals from upper right
        boolean inDiagonal2 = true;
        char value2 = game[0][game.length - 1];
        if (value2 == '_') {
            inDiagonal2 = false;
        } else {
            for (int i = 1; i < game.length; i++) {
                if (game[i][game.length - 1 - i] != value2) {
                    inDiagonal2 = false;
                    break;
                }
            }
        }
        if (inDiagonal2) {
            return value2;

        }
        //no winner
        return ' ';
    }

    public static boolean fullBoard(char[][] game) {
        for (int i = 0; i < game.length; i++) {
            for (int j = 0; j < game[i].length; j++) {
                if (game[i][j] == '_') {
                    return false;
                }
            }
        }
        //to check all cells we need to loop through
            return false;
    }
    }







